package com.example.systemgameofmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText name;
    private EditText password;
    private Button login;
    private Button registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setComponent();
    }
    private void setComponent(){
        name = (EditText) findViewById(R.id.etvName);
        password = (EditText) findViewById(R.id.etvPassword);

        login= (Button) findViewById(R.id.btLogin);
        registrar= (Button) findViewById(R.id.btRegistrar);
    }

    public void login (View v){
        if ((name.getText().toString().trim().equals("1")) & (password.getText().toString().trim().equals("1"))){
            Toast.makeText(this, "Page Admin", Toast.LENGTH_SHORT).show();
            Intent PageAdmin= new Intent(this,PageAdmin.class);
            startActivity(PageAdmin);
        }
        else if ((name.getText().toString().trim().equals("2")) & (password.getText().toString().trim().equals("2"))){
            Toast.makeText(this, "Page User", Toast.LENGTH_SHORT).show();
            Intent PageUser= new Intent(this,PageUser.class);
            startActivity(PageUser);
        }
        else {
            Toast.makeText(this,"Enter Value, please",Toast.LENGTH_SHORT).show();
        }
    }

    public void registrar (View v){
        Intent PageRegistro= new Intent(this,PageRegistro.class);
        startActivity(PageRegistro);
    }
}