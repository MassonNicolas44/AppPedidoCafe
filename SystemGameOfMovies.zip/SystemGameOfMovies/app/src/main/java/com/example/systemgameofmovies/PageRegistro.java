package com.example.systemgameofmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PageRegistro extends AppCompatActivity {

    private EditText nombre;
    private EditText apellido;
    private EditText TEL;
    private EditText mail;

    private Button aceptar;
    private Button cancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_registro);

        setComponent();
    }

    private void setComponent(){
        nombre = (EditText) findViewById(R.id.etvNombre);
        apellido = (EditText) findViewById(R.id.etvApellido);
        TEL = (EditText) findViewById(R.id.etvTEL);
        mail = (EditText) findViewById(R.id.etvMail);

        aceptar = (Button) findViewById(R.id.btAceptar);
        cancelar = (Button) findViewById(R.id.btCancelar);
    }

    public void login(View v){
        if ((nombre.getText().toString().trim().isEmpty())||(apellido.getText().toString().trim().isEmpty())||(TEL.getText().toString().trim().isEmpty())||(mail.getText().toString().trim().isEmpty())){
            Intent PageMain= new Intent(this,MainActivity.class);
            startActivity(PageMain);
        }
        else{
            Toast.makeText(this,"Enter Value, please",Toast.LENGTH_SHORT).show();
        }
    }

    public void cancel(View v){
        nombre.setText("");
        apellido.setText("");
        TEL.setText("");
        mail.setText("");
        Intent PageMain= new Intent(this,MainActivity.class);
        startActivity(PageMain);
    }
}