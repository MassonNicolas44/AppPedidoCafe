package com.example.systemgameofmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class PageUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listapelicula);

        final ArrayList<Pelicula> peliculas = new ArrayList<Pelicula>();

        peliculas.add(new Pelicula("Avenger","1.30hs","+16","accion","2D"));
        peliculas.add(new Pelicula("Rocky","1.45hs","ATP","accion","3D"));
        peliculas.add(new Pelicula("Fast&Furius","2.30hs","+13","accion,drama","3D"));
        peliculas.add(new Pelicula("Batman ","1.20hs","+8","comedia","3D"));

        PeliculaAdaptador adapter = new PeliculaAdaptador (this, peliculas);

        ListView listaPelicula = (ListView) findViewById(R.id.vista);
        listaPelicula.setAdapter(adapter);
        listaPelicula.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Pelicula pelicula = peliculas.get(position);
                Toast.makeText(PageUser.this, "Selected " + pelicula.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }
}