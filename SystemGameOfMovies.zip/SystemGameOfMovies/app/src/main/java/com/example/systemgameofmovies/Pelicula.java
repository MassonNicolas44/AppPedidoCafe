package com.example.systemgameofmovies;

public class Pelicula {

    private String mtitulo;
    private String mduracion;
    private String mrestriccionEdad;
    private String mcategoria;
    private String mtipo;
    //private int mimagen;

    public Pelicula(String titulo, String duracion,String restriccionEdad,String categoria,String tipo) {
        mtitulo = titulo;
        mduracion = duracion;
        mrestriccionEdad = restriccionEdad;
        mcategoria = categoria;
        mtipo = tipo;

        //mimagen=imagen;
    }

    public String gettitulo() {
        return mtitulo;
    }
    public String getduracion() {
        return mduracion;
    }
    public String getrestriccionEdad() {
        return mrestriccionEdad;
    }
    public String getcategoria() {
        return mcategoria;
    }
    public String gettipo() {
        return mtipo;
    }

    //public int getimagen() {
     //   return mimagen;
    //}

    @Override
    public java.lang.String toString() {
        return "Pelicula{" +
                "titulo='" + mtitulo + '\'' +
                ", duracion='" + mduracion + '\'' +
                "restriccion edad='" + mrestriccionEdad + '\'' +
                "categoria='" + mcategoria + '\'' +
                "tipo='" + mtipo + '\'' +
                '}';
    }
}
