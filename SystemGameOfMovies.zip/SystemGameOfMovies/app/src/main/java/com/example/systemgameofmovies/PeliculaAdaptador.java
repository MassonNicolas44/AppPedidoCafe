package com.example.systemgameofmovies;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class PeliculaAdaptador extends ArrayAdapter<Pelicula> {

    public PeliculaAdaptador(Activity context, ArrayList<Pelicula> peliculas){
        super(context,0,peliculas);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.activity_page_user, parent, false);
        }
        Pelicula currentWord = getItem(position);

        TextView titulo = (TextView) listItemView.findViewById(R.id.titulo);
        titulo.setText(currentWord.gettitulo());

        TextView duracion = (TextView) listItemView.findViewById(R.id.duracion);
        duracion.setText(currentWord.getduracion());

        TextView restriccionEdad= (TextView) listItemView.findViewById(R.id.restriccionEdad);
        restriccionEdad.setText(currentWord.getrestriccionEdad());

        TextView categoria= (TextView) listItemView.findViewById(R.id.categoria);
        categoria.setText(currentWord.getcategoria());

        TextView tipo= (TextView) listItemView.findViewById(R.id.tipo);
        tipo.setText(currentWord.gettipo());

       // ImageView imagen= (ImageView) listItemView.findViewById(R.id.imagen);
        //imagen.setImageResource(currentWord.getimagen());

        //View listaPelicula=listItemView.findViewById(R.id.listaPelicula);

        return listItemView;
    }
}
